package randomTextGenerator;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class GenText {

	private static boolean debugMode = false;

	private static final int LINELENGTH = 80;
	private static int prefixLength;
	private static int numWords;
	private static String sourceFile;
	private static String outFile;

	private static String[] sourceFileContent;
	private static ArrayList<String> outFileContent;
	private static HashMap<ArrayList<String>, HashMap<String, Integer>> map;

	public static void main(String[] args) {

		// init & argument check
		init(args);

		// process
		Preprocess preprocess = new Preprocess(prefixLength, sourceFileContent);
		map = preprocess.getPreMap();
		Prefix prefix = new Prefix(prefixLength, sourceFileContent);
		prefix.init();
		RandomTextGenerator randomTextGenerator = new RandomTextGenerator(prefix, map, debugMode);
		outFileContent = randomTextGenerator.generator(numWords);

		// write
		if (debugMode) {
			outprint(outFileContent);
		} else {
			ArrayList<String> writerFileContent = new ArrayList<String>();
			StringBuilder tmp = new StringBuilder();
			for (int i = 0; i < outFileContent.size(); i++) {
				if ((tmp.length() + outFileContent.get(i).length() + " ".length()) <= LINELENGTH) {
					tmp.append(outFileContent.get(i) + " ");
				} else if ((tmp.length() + outFileContent.get(i).length()) <= LINELENGTH) {
					tmp.append(outFileContent.get(i));
				} else {
					writerFileContent.add(tmp.toString());
					tmp = new StringBuilder();
					i--;
				}
			}
			writerFileContent.add(tmp.toString());
			outprint(writerFileContent);
		}

	}

	private static void init(String[] args) {
		// process arguments
		int offset = 0;
		if (args[0].equals("-d")) {
			debugMode = true;
			offset = 1;
		}
		if (args.length != (4 + offset)) {
			errorReport("missing command-line arguments"
					+ "\nusage: java GenText [-d] prefixLength numWords sourceFile outFile");
		}
		try {
			prefixLength = Integer.valueOf(args[0 + offset]);
			numWords = Integer.valueOf(args[1 + offset]);
		} catch (NumberFormatException e) {
			errorReport("prefixLength and numWords arguments should be integers"
					+ "\nusage: java GenText [-d] prefixLength numWords sourceFile outFile");
		}
		if (numWords < 0) {
			errorReport("numWords < 0" + "\nusage: java GenText [-d] prefixLength numWords sourceFile outFile");
		}
		if (prefixLength < 1) {
			errorReport("prefixLength < 1" + "\nusage: java GenText [-d] prefixLength numWords sourceFile outFile");
		}
		sourceFile = args[2 + offset];
		outFile = args[3 + offset];

		// open file
		FileInputStream in;
		byte[] buffer = null;
		try {
			in = new FileInputStream(sourceFile);
			buffer = new byte[in.available()];
			in.read(buffer);
			in.close();
		} catch (FileNotFoundException e) {
			errorReport("input file does not exist");
		} catch (IOException e) {
			e.printStackTrace();
		}
		sourceFileContent = new String(buffer).split("\\s+");
		if (prefixLength >= sourceFile.length()) {
			errorReport("prefixLength >= number of words in sourceFile");
		}
	}

	private static void outprint(ArrayList<String> content) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(outFile));
			for (int i = 0; i < content.size(); i++) {
				writer.write(content.get(i));
				writer.newLine();
			}
			writer.flush();
			writer.close();
		} catch (IOException e) {
			errorReport("can't write to output file");
		}
	}

	private static void errorReport(String errorMsg) {
		System.err.println("Error Message: " + errorMsg);
		System.exit(0);
	}
}
