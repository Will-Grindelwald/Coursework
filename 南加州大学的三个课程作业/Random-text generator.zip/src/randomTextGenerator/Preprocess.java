package randomTextGenerator;

import java.util.ArrayList;
import java.util.HashMap;

public class Preprocess {

	private int prefixLength;
	private String[] sourceFileContent;
	private HashMap<ArrayList<String>, HashMap<String, Integer>> preMap;

	public Preprocess(int prefixLength, String[] sourceFileContent) {
		this.prefixLength = prefixLength;
		this.sourceFileContent = sourceFileContent;
		this.preMap = new HashMap<>();
	}

	public HashMap<ArrayList<String>, HashMap<String, Integer>> getPreMap() {
		for (int i = 0; i < (sourceFileContent.length - prefixLength); i++) {
			ArrayList<String> key = new ArrayList<String>();
			for (int j = i; (j - i) <= prefixLength; j++) {
				HashMap<String, Integer> value = new HashMap<String, Integer>();
				if ((j - i) < prefixLength) {
					key.add(sourceFileContent[j]);
				} else {
					if (preMap.containsKey(key)) {
						value = preMap.get(key);
						if (value.containsKey(sourceFileContent[j])) {
							int num = value.get(sourceFileContent[j]);
							num++;
							value.put(sourceFileContent[j], num);
						} else {
							value.put(sourceFileContent[j], 1);
						}
						preMap.put(key, (HashMap<String, Integer>) value);
					} else {
						value.put(sourceFileContent[j], 1);
						preMap.put(key, (HashMap<String, Integer>) value);
					}
				}
			}
		}
		return preMap;
	}

}
