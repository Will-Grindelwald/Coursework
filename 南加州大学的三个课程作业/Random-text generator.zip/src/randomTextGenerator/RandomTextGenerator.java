package randomTextGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

public class RandomTextGenerator {

	private Prefix prefix;
	private HashMap<ArrayList<String>, HashMap<String, Integer>> map;
	private boolean debugMode;
	private Random random;

	public RandomTextGenerator(Prefix prefix, HashMap<ArrayList<String>, HashMap<String, Integer>> map,
			boolean debugMode) {
		this.prefix = prefix;
		this.map = map;
		this.debugMode = debugMode;
		if (debugMode)
			this.random = new Random(1);
		else
			this.random = new Random();
	}

	private String nextWord(ArrayList<String> output) {
		if (debugMode)
			output.add("DEBUG: prefix: " + prefix.getPrefix());
		HashMap<String, Integer> suffixMap = map.get(prefix.getPrefix());
		if (suffixMap == null)
			return null;
		if (debugMode)
			output.add("DEBUG: successors: " + suffixMap.keySet());
		Set<Entry<String, Integer>> suffixes = suffixMap.entrySet();
		int sum = 0;
		for (Entry<String, Integer> suffix : suffixes)
			sum += suffix.getValue();
		int randIndex = random.nextInt(sum);
		for (Entry<String, Integer> suffix : suffixes)
			if ((randIndex -= suffix.getValue()) < 0) {
				if (debugMode)
					output.add("DEBUG: word generated: " + suffix.getKey());
				return suffix.getKey();
			}
		return null;
	}

	public ArrayList<String> generator(int numWords) {
		ArrayList<String> output = new ArrayList<String>();
		prefix.init();
		if (debugMode)
			output.add("DEBUG: chose a new initial prefix: " + prefix.getPrefix());
		String newWord = null;
		for (int i = 0; i < numWords; i++) {
			if ((newWord = nextWord(output)) == null) {
				if (debugMode)
					output.add("DEBUG: successors: <END OF FILE>");
				do {
					prefix.init();
				} while ((newWord = nextWord(output)) == null);
				if (debugMode)
					output.add("DEBUG: chose a new initial prefix: " + prefix.getPrefix());
			}
			if (!debugMode)
				output.add(newWord);
			prefix.updata(newWord);
		}
		return output;
	}

}
