package randomTextGenerator;

import java.util.ArrayList;

public class Prefix {

	private int prefixLength;
	private String[] sourcrFileContent;

	private ArrayList<String> prefix;

	public Prefix(int prefixLength, String[] sourcrFileContent) {
		this.prefixLength = prefixLength;
		this.sourcrFileContent = sourcrFileContent;
		this.prefix = new ArrayList<String>();
	}

	public ArrayList<String> getPrefix() {
		return prefix;
	}

	public void updata(String newWord) {
		prefix.remove(0);
		prefix.add(prefixLength - 1, newWord);
	}

	public void init() {
		prefix.clear();
		int index = (int) (Math.random() * (sourcrFileContent.length - prefixLength + 1));
		for (int i = 0; i < prefixLength; i++)
			prefix.add(sourcrFileContent[index + i]);
	}

}
