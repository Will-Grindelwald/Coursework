// Name:
// Loginid:
// CSCI 455 PA5
// Fall 2016

#include <iostream>

#include <cassert>

#include "listFuncs.h"

using namespace std;

Node::Node(const string &theKey, int theValue)
{
    key = theKey;
    value = theValue;
    next = NULL;
}

Node::Node(const string &theKey, int theValue, Node *n)
{
    key = theKey;
    value = theValue;
    next = n;
}

//*************************************************************************
// put the function definitions for your list functions below

bool insertNode(ListType &list, string key, int value)
{
    Node *newNode = new Node(key, value);
    newNode->next = list;
    list = newNode;
    return true;
}

bool deleteNode(ListType &list, string key)
{
    Node *pre, *p = list;
    if (p && p->key == key)
    {
        list = p->next;
        delete (p);
        return true;
    }
    while (p && p->key != key)
    {
        pre = p;
        p = p->next;
    }
    if (p)
        return false;
    pre->next = p->next;
    delete (p);
    return true;
}

int getLenth(ListType list)
{
    int count = 0;
    Node *p = list;
    while (p)
    {
        count++;
        p = p->next;
    }
    return count;
}

Node *getElem(ListType list, string key)
{
    Node *p = list;
    while (p && p->key != key)
    {
        p = p->next;
    }
    return p;
}

void printAll0(ListType list)
{
    Node *p = list;
    while (p)
    {
        cout << p->key << ":" << p->value << endl;
        p = p->next;
    }
}
