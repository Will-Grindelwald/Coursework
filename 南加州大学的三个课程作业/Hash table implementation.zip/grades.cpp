// Name:
// Loginid:
// CSCI 455 PA5
// Fall 2016

/*
 * grades.cpp
 * A program to test the Table class.
 * How to run it:
 *     grades [hashSize]
 * 
 * the optional argument hashSize is the size of hash table to use.
 * if it's not given, the program uses default size (Table::HASH_SIZE)
 *
 */

#include "Table.h"

// cstdlib needed for call to atoi
#include <cstdlib>
#include <string>

string *str_split(string str);

void help(ostream &out);

int main(int argc, char *argv[])
{

    // gets the hash table size from the command line

    int hashSize = Table::HASH_SIZE;

    Table *grades; // Table is dynamically allocated below, so we can call
                   // different constructors depending on input from the user.

    if (argc > 1)
    {
        hashSize = atoi(argv[1]); // atoi converts c-string to int

        if (hashSize < 1)
        {
            cout << "Command line argument (hashSize) must be a positive number" << endl;
            return 1;
        }

        grades = new Table(hashSize);
    } else { // no command line args given -- use default table size
        grades = new Table();
    }

    grades->hashStats(cout);

    // add more code here
    // Reminder: use -> when calling Table methods, since grades is type Table*

    string cmd, *args;
    cout << "cmd> ";
    while (getline(cin, cmd))
    {
        args = str_split(cmd);
        if (args[0] == "insert") {
            if (!grades->insert(args[1], atoi(args[2].c_str())))
                cout << "this name was already present" << endl;
        } else if (args[0] == "change") {
            if (!grades->remove(args[1]))
                cout << "this name isn't present" << endl;
            else
                grades->insert(args[1], atoi(args[2].c_str()));
        } else if (args[0] == "lookup") {
            int *score;
            if (!(score = grades->lookup(args[1])))
                cout << "this student is not in the table" << endl;
            else
                cout << "name: " << args[1] << " score： " << *score << endl;
        } else if (args[0] == "remove") {
            if (!grades->remove(args[1]))
                cout << "this student wasn't in the grade table" << endl;
        } else if (args[0] == "print") {
            grades->printAll();
        } else if (args[0] == "size") {
            cout << "number of entries: " << grades->numEntries() << endl;
        } else if (args[0] == "stats") {
            grades->hashStats(cout);
        } else if (args[0] == "help") {
            help(cout);
        } else if (args[0] == "quit") {
            break;
        } else {
            cout << "ERROR: invalid command" << endl;
        }
        cout << "cmd> ";
    }

    return 0;
}

string *str_split(string str)
{
    string *a = new string[4];
    int n = str.find(" ");
    if (n <= 0)
    {
        a[0] = str;
        return a;
    }
    string sub = str.substr(0, n);
    a[0] = sub;
    string last = str.substr(n + 1, str.size());
    int m = last.find(" ");
    if (m <= 0)
    {
        a[1] = last;
        return a;
    }
    a[1] = last.substr(0, m);
    a[2] = last.substr(m + 1, last.size());
    return a;
}

void help(ostream &out)
{
    out << "insert name score" << endl;
    out << "\tInsert this name and score in the grade table. If this name was already present, print a message to that effect, and don't do the insert." << endl;
    out << "change name newscore" << endl;
    out << "\tChange the score for name. Print an appropriate message if this name isn't present." << endl;
    out << "lookup name" << endl;
    out << "\tLookup the name, and print out his or her score, or a message indicating that student is not in the table." << endl;
    out << "remove name" << endl;
    out << "\tRemove this student. If this student wasn't in the grade table, print a message to that effect." << endl;
    out << "print" << endl;
    out << "\tPrints out all names and scores in the table." << endl;
    out << "size" << endl;
    out << "\tPrints out the number of entries in the table." << endl;
    out << "stats" << endl;
    out << "\tPrints out statistics about the hash table at this point. (Calls hashStats() method)" << endl;
    out << "help" << endl;
    out << "\tPrints out a brief command summary." << endl;
    out << "quit" << endl;
    out << "\tExits the program." << endl;
}
