// Name:
// Loginid:
// CSCI 455 PA5
// Fall 2016

// Table.cpp  Table class implementation

/*
 * Modified 11/22/11 by CMB
 *   changed name of constructor formal parameter to match .h file
 */

#include "Table.h"

#include <iostream>
#include <string>
#include <cassert>

// listFuncs.h has the definition of Node and its methods.  -- when
// you complete it it will also have the function prototypes for your
// list functions.  With this #include, you can use Node type (and
// Node*, and ListType), and call those list functions from inside
// your Table methods, below.

#include "listFuncs.h"

//*************************************************************************

Table::Table()
{
    list = new ListType[HASH_SIZE]();
    hashSize = HASH_SIZE;
}

Table::Table(unsigned int hSize)
{
    list = new ListType[hSize]();
    hashSize = hSize;
}

bool Table::insert(const string &key, int value)
{
    Node *p = getElem(list[hashCode(key)], key);
    if (p)
        return false;
    else
        return insertNode(list[hashCode(key)], key, value);
}

int *Table::lookup(const string &key)
{
    Node *p = getElem(list[hashCode(key)], key);
    if (p)
        return &(p->value);
    return NULL;
}

bool Table::remove(const string &key)
{
    Node *p = getElem(list[hashCode(key)], key);
    if (p)
        return deleteNode(list[hashCode(key)], key);
    return false;
}

void Table::printAll() const
{
    for (int i = 0; i < hashSize; i++)
        printAll0(list[i]);
}

int Table::numEntries() const
{
    int sum = 0;
    for (int i = 0; i < hashSize; i++)
        sum += getLenth(list[i]);
    return sum;
}

void Table::hashStats(ostream &out) const
{
    out << "number of buckets: " << hashSize << endl;
    out << "number of entries: " << numEntries() << endl;

    int count = 0;
    for (int i = 0; i < hashSize; i++)
        if (list[i])
            count++;
    out << "number of non-empty buckets: " << count << endl;
    int max = 0, tmp;
    for (int i = 0; i < hashSize; i++)
        if ((tmp = getLenth(list[i])) > max)
            max = tmp;
    out << "longest chain: " << max << endl;
}

// add definitions for your private methods here
