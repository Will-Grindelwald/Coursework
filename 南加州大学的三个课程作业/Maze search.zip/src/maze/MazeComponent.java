package maze;

// Name:
// USC loginid:
// CS 455 PA3
// Fall 2016

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;
import java.util.ListIterator;

import javax.swing.JComponent;

/**
 * MazeComponent class
 * 
 * A component that displays the maze and path through it if one has been found.
 */
public class MazeComponent extends JComponent {
	private Maze maze;

	private static final int START_X = 10; // where to start drawing maze in frame
	private static final int START_Y = 10;
	private static final int BOX_WIDTH = 20; // width and height of one maze unit
	private static final int BOX_HEIGHT = 20;
	private static final int INSET = 2;
	// how much smaller on each side to make entry/exit inner box

	private static final int E_START_X = START_X + INSET; // where to start drawing entry/exit
	private static final int E_START_Y = START_Y + INSET;

	private static final int E_BOX_WIDTH = BOX_WIDTH - 2 * INSET;// width and height of entry/exit
	private static final int E_BOX_HEIGHT = BOX_HEIGHT - 2 * INSET;

	private int row;
	private int col;

	/**
	 * Constructs the component.
	 * 
	 * @param maze
	 *            the maze to display
	 */
	public MazeComponent(Maze maze) {
		this.row = maze.numRows();
		this.col = maze.numCols();
		this.maze = maze;
	}

	/**
	 * Draws the current state of maze including the path through it if one has
	 * been found.
	 * 
	 * @param g
	 *            the graphics context
	 */
	public void paintComponent(Graphics g) {
		Graphics graphics = (Graphics) g;

		graphics.drawRect(START_X, START_Y, BOX_WIDTH * col, BOX_HEIGHT * row);
		graphics.setColor(Color.BLACK);

		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++) {
				MazeCoord mazeCoord = new MazeCoord(i, j);
				if (maze.hasWallAt(mazeCoord)) {
					graphics.fillRect(START_X + BOX_WIDTH * j, START_Y + BOX_HEIGHT * i, BOX_WIDTH, BOX_HEIGHT);
				}
			}

		// draw entry
		graphics.setColor(Color.YELLOW);
		graphics.fillRect(E_START_X + BOX_WIDTH * maze.getEntryLoc().getCol(),
				E_START_Y + BOX_HEIGHT * maze.getEntryLoc().getRow(), E_BOX_WIDTH, E_BOX_HEIGHT);

		// draw exit
		graphics.setColor(Color.GREEN);
		graphics.fillRect(E_START_X + BOX_WIDTH * maze.getExitLoc().getCol(),
				E_START_Y + BOX_HEIGHT * maze.getExitLoc().getRow(), E_BOX_WIDTH, E_BOX_HEIGHT);

		graphics.setColor(Color.blue);
		LinkedList<MazeCoord> pathList = maze.getPath();
		if (!pathList.isEmpty()) {
			ListIterator<MazeCoord> iterator = pathList.listIterator();
			MazeCoord first = iterator.next();
			while (iterator.hasNext()) {
				MazeCoord second = iterator.next();
				graphics.drawLine(BOX_WIDTH * first.getCol() + BOX_WIDTH / 2 + START_X,
						BOX_HEIGHT * first.getRow() + BOX_HEIGHT / 2 + START_Y,
						BOX_WIDTH * second.getCol() + BOX_WIDTH / 2 + START_X,
						BOX_HEIGHT * second.getRow() + BOX_HEIGHT / 2 + START_Y);
				first = second;
			}
		}

	}

}
