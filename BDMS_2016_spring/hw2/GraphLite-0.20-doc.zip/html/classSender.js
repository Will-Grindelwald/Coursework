var classSender =
[
    [ "closeAllSocket", "classSender.html#a28f2418e5712a9f6fa70b82ac6ca417c", null ],
    [ "connectServer", "classSender.html#a4877f6ed8da8ae61d1cc0f89d14395ab", null ],
    [ "getServerAddr", "classSender.html#a4f85b6c0ae25757640babd68859b8db7", null ],
    [ "getSocketFd", "classSender.html#a5d1d67365988a5280a1b74ba328c96f8", null ],
    [ "init", "classSender.html#a4b1c2fafdb59afbbba56d2ff7fd8060f", null ],
    [ "sendMsg", "classSender.html#aa1a3ad39524ee77e654d192c6e82de62", null ],
    [ "m_fds", "classSender.html#a651c84edbbd76ae8bccaf71d3513a597", null ],
    [ "m_max_sock", "classSender.html#a7a25eff45b9b2c5423515eae45b47205", null ],
    [ "m_out_buffer", "classSender.html#aba5676154fed2ed9d063bd1170f86af2", null ],
    [ "m_out_cond", "classSender.html#ae08ddce6ba4c36fed8ec360f991b79e1", null ],
    [ "m_out_mutex", "classSender.html#add720c7db1560889852a8cf1971fcb54", null ],
    [ "m_serv_addr", "classSender.html#ad66e154f9f023f6fcc37e925f637e3d4", null ],
    [ "m_serv_cnt", "classSender.html#acf338cef9c47df4e697ad5112af105b2", null ],
    [ "m_sock_fd", "classSender.html#a59b1d7db18b862f370192c3ddd6f5ca3", null ]
];