var Master_8cc =
[
    [ "m_receiveFun", "Master_8cc.html#ac63aa0283843fe6379e40e603d51a1d1", null ],
    [ "m_sendFun", "Master_8cc.html#af53887ac0b9838a9f0ab3bad13852157", null ],
    [ "e_time", "Master_8cc.html#a58f192f851ccba6fe7af18f922e84e9d", null ],
    [ "elapsed", "Master_8cc.html#a0f9095a22b8368b9fc147fe97f745290", null ],
    [ "master", "Master_8cc.html#ac56411911dcd03046c12a3ef02567dfd", null ]
];