var searchData=
[
  ['value',['value',['../classNode.html#ad46cb7b58df0d035bbec7703afbafee8',1,'Node']]]
];
