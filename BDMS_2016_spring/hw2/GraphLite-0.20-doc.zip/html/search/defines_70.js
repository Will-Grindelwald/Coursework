var searchData=
[
  ['prefetch',['prefetch',['../Worker_8cc.html#a2e4dbe7e45641c38270529be0cbe0595',1,'Worker.cc']]],
  ['prefetchnta',['prefetchnta',['../Worker_8cc.html#a1c56d85f61bac58243a858c35d3362b0',1,'Worker.cc']]],
  ['prefetcht0',['prefetcht0',['../Worker_8cc.html#a238e233addb71cff7839b10b41c9d9e9',1,'Worker.cc']]],
  ['prefetcht1',['prefetcht1',['../Worker_8cc.html#a5688af1cc774eb3ac6c733e3e31b2aee',1,'Worker.cc']]],
  ['prefetcht2',['prefetcht2',['../Worker_8cc.html#a9c41f4014ce366df8ab86b92bfde002d',1,'Worker.cc']]]
];
