var searchData=
[
  ['sendlist_5flen',['SENDLIST_LEN',['../Utility_8h.html#ac9ce6dd6936651c8d1c986ef58c4e39a',1,'Utility.h']]],
  ['sprintf_5flen',['SPRINTF_LEN',['../Utility_8h.html#ad69c256c9995a7c54eadb2e7d28a3ef4',1,'Utility.h']]]
];
