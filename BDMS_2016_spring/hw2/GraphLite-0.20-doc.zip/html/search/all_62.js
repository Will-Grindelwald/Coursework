var searchData=
[
  ['bindserveraddr',['bindServerAddr',['../classReceiver.html#a057ce8b4294f7bff1a31eb0936ca2ce3',1,'Receiver']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../Utility_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'Utility.h']]]
];
