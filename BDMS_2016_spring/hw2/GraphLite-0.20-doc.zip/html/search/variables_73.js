var searchData=
[
  ['s_5fid',['s_id',['../structMsg.html#a0484c43db01feaea34f28501f6caec9b',1,'Msg']]]
];
