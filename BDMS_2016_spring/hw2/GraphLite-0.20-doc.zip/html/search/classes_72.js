var searchData=
[
  ['receiver',['Receiver',['../classReceiver.html',1,'']]],
  ['resultiterator',['ResultIterator',['../classWorker_1_1ResultIterator.html',1,'Worker']]],
  ['resultiterator',['ResultIterator',['../classOutputFormatter_1_1ResultIterator.html',1,'OutputFormatter']]]
];
