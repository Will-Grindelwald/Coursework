var searchData=
[
  ['vertex_5fclass_5fname',['VERTEX_CLASS_NAME',['../PageRankVertex_8cc.html#ae533acd12f5b852c017ecc2f5fad63f9',1,'PageRankVertex.cc']]]
];
