var searchData=
[
  ['m_5freceivefun',['m_receiveFun',['../Master_8cc.html#ac63aa0283843fe6379e40e603d51a1d1',1,'Master.cc']]],
  ['m_5fsendfun',['m_sendFun',['../Master_8cc.html#af53887ac0b9838a9f0ab3bad13852157',1,'Master.cc']]],
  ['main',['main',['../main_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cc']]],
  ['managesuperstep',['manageSuperstep',['../classMaster.html#a9e907b808fbcdbe162606d68706a6255',1,'Master']]],
  ['mastercomputeperstep',['masterComputePerstep',['../classGraph.html#adbfcc3b567d180957262a352dfc310e5',1,'Graph']]],
  ['merge',['merge',['../classAggregator.html#a260f0c839001b7b67f56dd8b80f12aef',1,'Aggregator::merge()'],['../classAggregatorBase.html#a17cc78a759ed8c8dab0164f54c6dd11b',1,'AggregatorBase::merge()']]],
  ['msgbuffer',['MsgBuffer',['../classMsgBuffer.html#a89e2658892ee1c9ae89ea3aa2091f424',1,'MsgBuffer']]],
  ['mutablevalue',['mutableValue',['../classVertex.html#afa0c61bdc54d874380d7af532b6c5124',1,'Vertex']]]
];
