var searchData=
[
  ['hostname',['hostname',['../structAddr.html#aa8826ea3b8e27f4fc77fd546fe1dfe6a',1,'Addr']]]
];
