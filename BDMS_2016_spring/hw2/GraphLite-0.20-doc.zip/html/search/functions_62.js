var searchData=
[
  ['bindserveraddr',['bindServerAddr',['../classReceiver.html#a057ce8b4294f7bff1a31eb0936ca2ce3',1,'Receiver']]]
];
