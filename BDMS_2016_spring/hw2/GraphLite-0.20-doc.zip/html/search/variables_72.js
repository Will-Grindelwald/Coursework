var searchData=
[
  ['res_5fiter',['res_iter',['../classWorker.html#afd5fa8a21cba74f7980d6c8f663ef544',1,'Worker']]]
];
