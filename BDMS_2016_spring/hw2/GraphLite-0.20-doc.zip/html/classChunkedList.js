var classChunkedList =
[
    [ "ChunkedList", "classChunkedList.html#aa3a96d0cc3147a02d85350e91f493189", null ],
    [ "~ChunkedList", "classChunkedList.html#ac265f5f3b01612900c9f1273b36606a5", null ],
    [ "allocateNewBlock", "classChunkedList.html#a8fc3a358d61f445ae0c542cc5d711482", null ],
    [ "append", "classChunkedList.html#acedee3e3bf26c68282754b1d8c05cf74", null ],
    [ "getIterator", "classChunkedList.html#a1f3b72e90fa0285c9eacca469e08ff31", null ],
    [ "getTail", "classChunkedList.html#a3b56f22c5cf8a2becc843e9d42b37b46", null ],
    [ "initIterator", "classChunkedList.html#a9d4b7c3337b31882028ac8fa619d5290", null ],
    [ "isEmpty", "classChunkedList.html#aee9a0c702f5ccd78bcc94e1143a2f9a8", null ],
    [ "total", "classChunkedList.html#a9dd2acc6ec22936f2c7b3d5419d9bcba", null ],
    [ "m_cur_mem_pool", "classChunkedList.html#a68e01040c94f19534315d83aa59ae977", null ],
    [ "m_mem_pool_capacity", "classChunkedList.html#a2c7eeb4afdca329553fd92ba5fbd5b71", null ],
    [ "m_mem_pools", "classChunkedList.html#adc62be5aa7afa97efca99ef6d7b0a7b7", null ],
    [ "m_num_ele_per_buf", "classChunkedList.html#af3f96931c0c7875134b069b0b28c3231", null ],
    [ "m_pavail", "classChunkedList.html#a2d4ea73b6636f939a5f56d59efc388c6", null ],
    [ "m_pavail_begin", "classChunkedList.html#a2d0cb1305407d215dcdad997ecacf606", null ],
    [ "m_pavail_end", "classChunkedList.html#a3e138bb929272ac4d52e98de3deae793", null ]
];