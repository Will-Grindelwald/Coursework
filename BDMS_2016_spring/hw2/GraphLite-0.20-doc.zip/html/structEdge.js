var structEdge =
[
    [ "e_size", "structEdge.html#a4bb1b4856beb1eedbd9b90f9117068b1", null ],
    [ "e_value_size", "structEdge.html#ab7222607d4b69d23575c22af3e5f0414", null ],
    [ "from", "structEdge.html#a0842cc7b1493f5365c93c03e9e75c565", null ],
    [ "to", "structEdge.html#a2269c96ec07129b87e6c34ecfa25e0de", null ],
    [ "weight", "structEdge.html#a178520e38ae84b142956e3f6b76484d6", null ]
];