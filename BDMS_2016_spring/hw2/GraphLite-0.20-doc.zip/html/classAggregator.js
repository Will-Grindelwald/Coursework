var classAggregator =
[
    [ "accumulate", "classAggregator.html#a97b735b4f4dc52c9f6ab275cf6fac3d0", null ],
    [ "getGlobal", "classAggregator.html#ad0b5b9deb16194ab8745bbb01d329920", null ],
    [ "getLocal", "classAggregator.html#ae1f58ffcd33e958359ae2766deb60227", null ],
    [ "getSize", "classAggregator.html#a90d880ad91813328f5121696b8506ff0", null ],
    [ "init", "classAggregator.html#a95a1b502bb1fd7edd8880a148a918b7e", null ],
    [ "merge", "classAggregator.html#a260f0c839001b7b67f56dd8b80f12aef", null ],
    [ "setGlobal", "classAggregator.html#a0dd10d87e35e3f136c22711b820cf905", null ],
    [ "m_global", "classAggregator.html#aadf3f884e62d66f16b5d127d6a9fb828", null ],
    [ "m_local", "classAggregator.html#ad39416574d393b29b130c40d3e4c230a", null ]
];