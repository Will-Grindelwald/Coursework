var structMsg =
[
    [ "d_id", "structMsg.html#af2cc2a33d0a0874f9ce4f33fe80aa477", null ],
    [ "m_size", "structMsg.html#aa52ef84365c5aecd1604cbc0f0fa3f19", null ],
    [ "m_value_size", "structMsg.html#a34b6be9772c2411a0392d231749c3196", null ],
    [ "message", "structMsg.html#af745228407edc11e85e7b86e7cb35529", null ],
    [ "s_id", "structMsg.html#a0484c43db01feaea34f28501f6caec9b", null ]
];