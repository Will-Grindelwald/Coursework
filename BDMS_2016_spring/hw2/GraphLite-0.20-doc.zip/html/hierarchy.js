var hierarchy =
[
    [ "Addr", "structAddr.html", null ],
    [ "AggregatorBase", "classAggregatorBase.html", [
      [ "Aggregator< AggrValue >", "classAggregator.html", null ]
    ] ],
    [ "ChunkedList", "classChunkedList.html", null ],
    [ "Edge", "structEdge.html", null ],
    [ "FreeList", "classFreeList.html", null ],
    [ "GenericArrayIterator", "classGenericArrayIterator.html", [
      [ "Vertex< VertexValue, EdgeValue, MessageValue >::OutEdgeIterator", "classVertex_1_1OutEdgeIterator.html", null ]
    ] ],
    [ "GenericLinkIterator", "classGenericLinkIterator.html", [
      [ "Vertex< VertexValue, EdgeValue, MessageValue >::MessageIterator", "classVertex_1_1MessageIterator.html", null ]
    ] ],
    [ "Graph", "classGraph.html", null ],
    [ "InputFormatter", "classInputFormatter.html", null ],
    [ "ChunkedList::Iterator", "classChunkedList_1_1Iterator.html", null ],
    [ "Master", "classMaster.html", null ],
    [ "Msg", "structMsg.html", null ],
    [ "MsgBuffer", "classMsgBuffer.html", null ],
    [ "Node", "classNode.html", null ],
    [ "OutputFormatter", "classOutputFormatter.html", null ],
    [ "Receiver", "classReceiver.html", null ],
    [ "OutputFormatter::ResultIterator", "classOutputFormatter_1_1ResultIterator.html", null ],
    [ "Worker::ResultIterator", "classWorker_1_1ResultIterator.html", null ],
    [ "Sender", "classSender.html", null ],
    [ "VertexBase", "classVertexBase.html", [
      [ "Vertex< VertexValue, EdgeValue, MessageValue >", "classVertex.html", null ]
    ] ],
    [ "Worker", "classWorker.html", null ]
];