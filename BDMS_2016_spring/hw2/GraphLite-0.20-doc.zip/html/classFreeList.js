var classFreeList =
[
    [ "FreeList", "classFreeList.html#a2f0ebe469e4c1c67ca28f6fee62167a5", null ],
    [ "~FreeList", "classFreeList.html#aed17e781eba0d5b06bd67662eeec2405", null ],
    [ "allocate", "classFreeList.html#a5b9c78e5200a2a9c62dcb8337b955469", null ],
    [ "allocateNewBlock", "classFreeList.html#a12d4fa2e120ed7aa041daacdb1fd373c", null ],
    [ "free", "classFreeList.html#a960f560da1ae383a841397c4f7d20d67", null ],
    [ "setEle", "classFreeList.html#ac8d526f46ecd68010f1b9ec26d05dffb", null ],
    [ "m_chunked_list", "classFreeList.html#a52b2a72c4a4d688c2cdb23f624cb3b16", null ],
    [ "m_element_size", "classFreeList.html#aa067988518cd6b3dcf26796703469421", null ],
    [ "m_mem_pool_capacity", "classFreeList.html#a0bc2f49a3c1a488f9c1f6f78358ff372", null ],
    [ "m_mem_pools", "classFreeList.html#a5cb6c8c3d18b9cdc2b298795a4a7f473", null ]
];