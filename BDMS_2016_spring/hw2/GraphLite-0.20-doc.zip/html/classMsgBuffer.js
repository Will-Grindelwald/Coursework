var classMsgBuffer =
[
    [ "MsgBuffer", "classMsgBuffer.html#a89e2658892ee1c9ae89ea3aa2091f424", null ],
    [ "m_buf_len", "classMsgBuffer.html#ad7a0d0e6d40985d00cd5596fd702eb27", null ],
    [ "m_buffer", "classMsgBuffer.html#a7720e04c24321238863c70ef0050955a", null ],
    [ "m_head", "classMsgBuffer.html#a2156d6f352815412408b21fe2e074f24", null ],
    [ "m_msg_len", "classMsgBuffer.html#a8c3ffe3cc763515865390805a36308c0", null ],
    [ "m_msg_type", "classMsgBuffer.html#a16feca8f219c493d7ccc8488b6797a7d", null ],
    [ "m_state", "classMsgBuffer.html#a51e4f214ba04e49ff289fb1c3b948adf", null ],
    [ "m_tail", "classMsgBuffer.html#ad88f02186587e9758f6fae7ded26423e", null ]
];