var classOutputFormatter =
[
    [ "~OutputFormatter", "classOutputFormatter.html#a3143adb109e97c2e614518cc21bbdd73", null ],
    [ "close", "classOutputFormatter.html#a0276d18e00c313a1f0cedf39825dff48", null ],
    [ "open", "classOutputFormatter.html#a3e156e03c72730f99c53e268b116bb81", null ],
    [ "writeNextResLine", "classOutputFormatter.html#a1ea03f523e23668bf0cf6e90e64aa9b7", null ],
    [ "writeResult", "classOutputFormatter.html#a6af0f0b40a00e8e35de0145ab65fad30", null ],
    [ "m_hdfs_file", "classOutputFormatter.html#aa42c6a8ab13105c64a5bb189a047c4fa", null ],
    [ "m_local_file", "classOutputFormatter.html#a20811ee10262ecf0ff6588c724667102", null ]
];