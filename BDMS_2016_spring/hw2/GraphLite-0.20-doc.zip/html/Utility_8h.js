var Utility_8h =
[
    [ "BUFFER_SIZE", "Utility_8h.html#a6b20d41d6252e9871430c242cb1a56e7", null ],
    [ "MEMPOOL_CAPACITY", "Utility_8h.html#ae0c02e3702c86a35d3a708a75e5291bc", null ],
    [ "SENDLIST_LEN", "Utility_8h.html#ac9ce6dd6936651c8d1c986ef58c4e39a", null ],
    [ "SPRINTF_LEN", "Utility_8h.html#ad69c256c9995a7c54eadb2e7d28a3ef4", null ],
    [ "IMDM", "Utility_8h.html#a0626aa4f43611387880515ea31fd353f", null ],
    [ "InMsgDeliverMethod", "Utility_8h.html#a30c7901b8fb9685763b19c2b2247f387", null ],
    [ "MessageType", "Utility_8h.html#ac6606ebe91c8ac66a2c314c79f5ab013", null ]
];