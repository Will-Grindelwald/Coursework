var main_8cc =
[
    [ "main", "main_8cc.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "usage", "main_8cc.html#aa8f7f6ce8f14343dc01a8f21dfae961b", null ],
    [ "main_term", "main_8cc.html#a45e3be6fb6a4df3a59aa4dd10d621225", null ],
    [ "master", "main_8cc.html#ac56411911dcd03046c12a3ef02567dfd", null ],
    [ "worker", "main_8cc.html#a2582a29ca2e2bbcb5e89a726dae92974", null ]
];