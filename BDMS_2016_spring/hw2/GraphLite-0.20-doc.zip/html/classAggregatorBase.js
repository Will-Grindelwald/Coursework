var classAggregatorBase =
[
    [ "accumulate", "classAggregatorBase.html#a3cd65b52afaac2d2c8f3d31ac162915e", null ],
    [ "getGlobal", "classAggregatorBase.html#ad68d6f020fee0abd104d28659e36dc95", null ],
    [ "getLocal", "classAggregatorBase.html#a3d52d5141c28cf072b37869935e781bc", null ],
    [ "getSize", "classAggregatorBase.html#ad5d92769cdd8a704f64414daa106d94b", null ],
    [ "init", "classAggregatorBase.html#a366db61dffcb049c6a25b35f4e8b83b0", null ],
    [ "merge", "classAggregatorBase.html#a17cc78a759ed8c8dab0164f54c6dd11b", null ],
    [ "setGlobal", "classAggregatorBase.html#a2966b1682b3df58a7a243ece4759ccb6", null ]
];