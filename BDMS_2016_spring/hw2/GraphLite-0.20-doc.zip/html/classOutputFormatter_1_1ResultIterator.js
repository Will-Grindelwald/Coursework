var classOutputFormatter_1_1ResultIterator =
[
    [ "done", "classOutputFormatter_1_1ResultIterator.html#ae29b6169edcf7951a587855232488847", null ],
    [ "getIdValue", "classOutputFormatter_1_1ResultIterator.html#a78c57e1819cca763407c6db57a705c30", null ],
    [ "next", "classOutputFormatter_1_1ResultIterator.html#af3b07481598e2ae7bb69a11bf663fa0a", null ]
];