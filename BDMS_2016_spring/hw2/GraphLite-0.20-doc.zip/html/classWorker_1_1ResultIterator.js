var classWorker_1_1ResultIterator =
[
    [ "done", "classWorker_1_1ResultIterator.html#afa6b8a3e8dfa28c92f28fc69055c5d9b", null ],
    [ "getIdValue", "classWorker_1_1ResultIterator.html#af8c0c8e3739bd756ccc2916bccc4c246", null ],
    [ "init", "classWorker_1_1ResultIterator.html#adfa6c957b61c95d5741da69ee7824ae6", null ],
    [ "next", "classWorker_1_1ResultIterator.html#a3c297ab6d6912ef6539f70d5702bf3bb", null ],
    [ "m_element_size", "classWorker_1_1ResultIterator.html#a5b2d5c83fd5d5f21eab134c11f2dcea6", null ],
    [ "m_pbegin", "classWorker_1_1ResultIterator.html#a072ed10b42a4f13dfb9f4783e75068a6", null ],
    [ "m_pend", "classWorker_1_1ResultIterator.html#ab4ed19cc0e82c430637c297bbfe0fe25", null ]
];