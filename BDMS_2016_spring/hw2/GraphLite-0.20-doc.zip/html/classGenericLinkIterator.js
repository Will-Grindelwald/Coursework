var classGenericLinkIterator =
[
    [ "GenericLinkIterator", "classGenericLinkIterator.html#acf1e1b2d938c27b5f45c23bfadc63dbd", null ],
    [ "done", "classGenericLinkIterator.html#ae1659d726ccf7ecb6cc335627c809984", null ],
    [ "getCurrent", "classGenericLinkIterator.html#ac94d39bf99ea5321be60d30067bd779b", null ],
    [ "next", "classGenericLinkIterator.html#a7b8a4e6afee599ba3e82eadd702d64b5", null ],
    [ "m_cur_index", "classGenericLinkIterator.html#a180470f2b1327bd7c8335f4b145ba861", null ],
    [ "m_pvector", "classGenericLinkIterator.html#ad25eb272d149dcc139ec835baed580fb", null ],
    [ "m_vector_size", "classGenericLinkIterator.html#ae21a365348707243cdb69201421d32bb", null ]
];