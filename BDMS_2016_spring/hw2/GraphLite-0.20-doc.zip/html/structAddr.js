var structAddr =
[
    [ "hostname", "structAddr.html#aa8826ea3b8e27f4fc77fd546fe1dfe6a", null ],
    [ "id", "structAddr.html#a578f1e15dd8c41ad02027b0f7596aab3", null ],
    [ "port", "structAddr.html#ae637f819a25d7cce524a396b0f650ef0", null ]
];